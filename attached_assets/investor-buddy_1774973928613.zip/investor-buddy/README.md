# Investor Buddy

A web-based stock screening application that lets users create custom screening criteria, evaluate stocks against those criteria, and receive AI-generated explanations of the results.

**Built with:** React, Express.js, SQLite, Alpha Vantage API, Anthropic Claude API

---

## Quick Start on Replit (Step-by-Step)

### Step 1: Create a New Repl
1. Go to [replit.com](https://replit.com) and sign in
2. Click **+ Create Repl**
3. Select the **Node.js** template
4. Name it `investor-buddy`
5. Click **Create Repl**

### Step 2: Upload Project Files
1. In Replit's file panel (left sidebar), delete the default `index.js` file
2. Drag and drop all the project files into the file panel, OR
3. Use Replit's "Upload file" button to upload each file maintaining the folder structure

### Step 3: Set Up Secrets (Environment Variables)
1. In Replit, click the **Secrets** tab (lock icon in the left sidebar)
2. Add these secrets:

| Key | Value | How to Get It |
|-----|-------|---------------|
| `ALPHA_VANTAGE_KEY` | Your API key | Free at [alphavantage.co/support/#api-key](https://www.alphavantage.co/support/#api-key) |
| `ANTHROPIC_API_KEY` | Your API key | From [console.anthropic.com](https://console.anthropic.com) |
| `JWT_SECRET` | Any random string | e.g. `investorbuddy2026secret` |

### Step 4: Install Dependencies
In the **Shell** tab, run:
```bash
npm install
```

### Step 5: Run the App
Click the green **Run** button, or in the Shell run:
```bash
npm run dev
```

The app will start and Replit will show a preview URL — that's your running app!

### Step 6: Seed Stock Data (Optional)
The app comes with pre-seeded data for 50 stocks. To refresh with live Alpha Vantage data:
```bash
node seed.js
```
Note: Alpha Vantage free tier allows 25 requests/day. The seed script will fetch as many as allowed and cache them.

---

## Features
- **User Authentication** — Register and login with email/password (bcrypt + JWT)
- **Criteria Builder** — Select from 10 financial metrics, set thresholds (>, <, between)
- **Screening Engine** — Evaluate 50 stocks against your criteria, scored 0–100
- **Results Page** — Ranked list with search/filter and watchlist toggle
- **AI Analysis** — Claude-powered plain-language explanations of stock scores
- **Watchlist** — Save and monitor stocks across sessions

## Tech Stack
- **Frontend:** React 18 (via Vite)
- **Backend:** Express.js
- **Database:** SQLite (via better-sqlite3)
- **Stock Data:** Alpha Vantage API (cached in SQLite)
- **AI:** Anthropic Claude API
- **Auth:** bcryptjs + JSON Web Tokens

## Project Structure
```
├── server.js          # Express API server (all routes)
├── seed.js            # Alpha Vantage data fetcher
├── package.json       # Dependencies and scripts
├── vite.config.js     # Vite configuration
├── index.html         # HTML entry point
├── src/
│   ├── main.jsx       # React entry point
│   └── App.jsx        # Complete React application
└── README.md
```

## API Routes
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Login |
| GET | `/api/criteria` | List user's criteria sets |
| POST | `/api/criteria` | Save criteria set |
| PUT | `/api/criteria/:id` | Update criteria set |
| DELETE | `/api/criteria/:id` | Delete criteria set |
| GET | `/api/stocks` | Get all cached stocks |
| POST | `/api/screen` | Run screening with criteria |
| GET | `/api/watchlist` | Get user's watchlist |
| POST | `/api/watchlist/:ticker` | Add to watchlist |
| DELETE | `/api/watchlist/:ticker` | Remove from watchlist |
| POST | `/api/analyze` | Get AI analysis for a stock |

## License
MIT

---

*Disclaimer: Investor Buddy is an informational tool only and does not constitute registered investment advice. Users are solely responsible for their own investment decisions.*

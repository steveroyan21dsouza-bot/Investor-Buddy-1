/**
 * Alpha Vantage Data Seeder
 * 
 * Fetches fundamental data for stocks in the database.
 * Free tier: 25 requests/day. Run daily to gradually update all stocks.
 * 
 * Usage: node seed.js
 */

import Database from "better-sqlite3";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const API_KEY = process.env.ALPHA_VANTAGE_KEY;

if (!API_KEY) {
  console.error("Error: Set ALPHA_VANTAGE_KEY in Replit Secrets first.");
  console.error("Get a free key at: https://www.alphavantage.co/support/#api-key");
  process.exit(1);
}

const db = new Database(join(__dirname, "investor_buddy.db"));
const RATE_LIMIT = 25; // Alpha Vantage free tier
const DELAY_MS = 13000; // ~13 seconds between requests to stay safe

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fetchOverview(ticker) {
  const url = `https://www.alphavantage.co/query?function=OVERVIEW&symbol=${ticker}&apikey=${API_KEY}`;
  const res = await fetch(url);
  const data = await res.json();
  
  if (data.Note || data.Information) {
    console.log("  ⚠ Rate limit reached. Stopping.");
    return null;
  }
  if (!data.Symbol) {
    console.log(`  ⚠ No data for ${ticker}`);
    return "skip";
  }
  return data;
}

async function main() {
  // Get stocks ordered by oldest update first
  const stocks = db.prepare(
    "SELECT ticker FROM stocks ORDER BY updated_at ASC LIMIT ?"
  ).all(RATE_LIMIT);

  console.log(`\nInvestor Buddy — Alpha Vantage Seeder`);
  console.log(`======================================`);
  console.log(`Found ${stocks.length} stocks to update (limit: ${RATE_LIMIT}/day)\n`);

  const update = db.prepare(`
    UPDATE stocks SET
      price = ?, pe_ratio = ?, debt_to_equity = ?, eps_growth = ?,
      dividend_yield = ?, roe = ?, revenue_growth = ?, profit_margin = ?,
      current_ratio = ?, market_cap_b = ?, beta = ?, updated_at = datetime('now')
    WHERE ticker = ?
  `);

  let updated = 0;
  for (const { ticker } of stocks) {
    process.stdout.write(`Fetching ${ticker}...`);
    
    const data = await fetchOverview(ticker);
    if (data === null) break; // Rate limited
    if (data === "skip") continue;

    const price = parseFloat(data["50DayMovingAverage"]) || parseFloat(data["200DayMovingAverage"]) || 0;
    const pe = parseFloat(data.PERatio) || 0;
    const de = parseFloat(data.DebtToEquityRatio) || 0;
    const epsG = (parseFloat(data.QuarterlyEarningsGrowthYOY) || 0) * 100;
    const divY = (parseFloat(data.DividendYield) || 0) * 100;
    const roe = (parseFloat(data.ReturnOnEquityTTM) || 0) * 100;
    const revG = (parseFloat(data.QuarterlyRevenueGrowthYOY) || 0) * 100;
    const pm = (parseFloat(data.ProfitMargin) || 0) * 100;
    const cr = parseFloat(data.CurrentRatio) || 0;
    const mcap = (parseFloat(data.MarketCapitalization) || 0) / 1e9;
    const beta = parseFloat(data.Beta) || 0;

    update.run(price, pe, de, epsG, divY, roe, revG, pm, cr, mcap, beta, ticker);
    updated++;
    console.log(` ✓ P/E: ${pe}, D/E: ${de}, Beta: ${beta}`);

    // Respect rate limits
    if (updated < stocks.length) {
      await sleep(DELAY_MS);
    }
  }

  console.log(`\nDone! Updated ${updated} stocks.`);
  if (updated < stocks.length) {
    console.log(`Run again tomorrow to update the remaining ${stocks.length - updated} stocks.`);
  }
  
  db.close();
}

main().catch(console.error);

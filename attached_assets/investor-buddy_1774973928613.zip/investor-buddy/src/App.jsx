import { useState, useEffect, useCallback, useRef } from "react";

// ─── CONFIG ─────────────────────────────────────────────────────────
const API = "/api";
const METRICS_LIBRARY = [
  { id: "pe_ratio", name: "P/E Ratio", desc: "Price-to-Earnings Ratio" },
  { id: "debt_to_equity", name: "Debt-to-Equity", desc: "Total Debt / Shareholder Equity" },
  { id: "eps_growth", name: "EPS Growth (%)", desc: "YoY earnings per share growth" },
  { id: "dividend_yield", name: "Dividend Yield (%)", desc: "Annual dividends / share price" },
  { id: "roe", name: "ROE (%)", desc: "Return on Equity" },
  { id: "revenue_growth", name: "Revenue Growth (%)", desc: "YoY revenue growth" },
  { id: "profit_margin", name: "Profit Margin (%)", desc: "Net income / revenue" },
  { id: "current_ratio", name: "Current Ratio", desc: "Current assets / current liabilities" },
  { id: "market_cap_b", name: "Market Cap ($B)", desc: "Market capitalization in billions" },
  { id: "beta", name: "Beta", desc: "Volatility relative to market" },
];

// ─── API HELPERS ────────────────────────────────────────────────────
function getToken() { return localStorage.getItem("ib_token"); }
function setToken(t) { localStorage.setItem("ib_token", t); }
function clearToken() { localStorage.removeItem("ib_token"); }

async function apiFetch(path, options = {}) {
  const token = getToken();
  const res = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

// ─── COLORS & STYLING ──────────────────────────────────────────────
const C = {
  primary: "#1E3A8A", primaryLight: "#3B5FBF", primaryFaint: "#EFF3FE",
  accent: "#10B981", accentLight: "#D1FAE5",
  bg: "#F8FAFC", card: "#FFFFFF", border: "#E2E8F0",
  text: "#111827", muted: "#64748B",
  error: "#EF4444", errorBg: "#FEF2F2", errorBorder: "#FECACA",
  successBg: "#F0FDF4", successBorder: "#BBF7D0",
};
const F = "'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif";
const MONO = "'JetBrains Mono', 'SF Mono', monospace";

// ─── SVG ICONS ──────────────────────────────────────────────────────
const paths = {
  home: "M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z|M9 21V12h6v9",
  filter: "M22 3H2l8 9.46V19l4 2v-8.54L22 3z",
  star: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
  play: "M5 3l14 9-14 9V3z",
  plus: "M12 5v14|M5 12h14",
  edit: "M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7|M18.5 2.5a2.12 2.12 0 013 3L12 15l-4 1 1-4 9.5-9.5z",
  trash: "M3 6h18|M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2|M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6",
  logout: "M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4|M16 17l5-5-5-5|M21 12H9",
  back: "M15 18l-6-6 6-6",
  check: "M20 6L9 17l-5-5",
  x: "M18 6L6 18|M6 6l12 12",
  search: "M21 21l-4.35-4.35",
  chart: "M18 20V10|M12 20V4|M6 20v-6",
  ai: "M12 2a10 10 0 100 20 10 10 0 000-20z|M12 6v2|M12 16v2|M6 12h2|M16 12h2",
  user: "M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2",
};

function Icon({ type, size = 18, color = "currentColor", fill = false }) {
  const d = paths[type] || "";
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
      {d.split("|").map((p, i) => (
        <path key={i} d={p} fill={type === "star" && fill ? color : "none"}
          stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      ))}
      {type === "search" && <circle cx="11" cy="11" r="8" fill="none" stroke={color} strokeWidth="2" />}
      {type === "user" && <circle cx="12" cy="7" r="4" fill="none" stroke={color} strokeWidth="2" />}
    </svg>
  );
}

// ─── REUSABLE COMPONENTS ────────────────────────────────────────────
function Btn({ children, onClick, v = "primary", sz = "md", disabled, icon, style }) {
  const base = {
    display: "inline-flex", alignItems: "center", gap: 6, border: "none",
    borderRadius: 8, cursor: disabled ? "not-allowed" : "pointer",
    fontFamily: F, fontWeight: 600, transition: "all 0.15s", opacity: disabled ? 0.5 : 1,
  };
  const sizes = { sm: { padding: "6px 12px", fontSize: 13 }, md: { padding: "10px 18px", fontSize: 14 }, lg: { padding: "12px 24px", fontSize: 15 } };
  const vars = {
    primary: { background: C.primary, color: "#fff" },
    accent: { background: C.accent, color: "#fff" },
    outline: { background: "transparent", color: C.primary, border: `1.5px solid ${C.primary}` },
    ghost: { background: "transparent", color: C.muted },
    danger: { background: C.error, color: "#fff" },
  };
  return (
    <button onClick={disabled ? undefined : onClick}
      style={{ ...base, ...sizes[sz], ...vars[v], ...style }}
      onMouseEnter={e => { if (!disabled) e.currentTarget.style.opacity = "0.85"; }}
      onMouseLeave={e => { e.currentTarget.style.opacity = disabled ? "0.5" : "1"; }}
    >
      {icon && <Icon type={icon} size={sz === "sm" ? 14 : 16} />}
      {children}
    </button>
  );
}

function Card({ children, style, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: C.card, borderRadius: 12, border: `1px solid ${C.border}`,
      padding: 20, cursor: onClick ? "pointer" : "default",
      transition: "box-shadow 0.15s, transform 0.15s", ...style,
    }}
    onMouseEnter={e => { if (onClick) { e.currentTarget.style.boxShadow = "0 4px 16px rgba(0,0,0,0.07)"; e.currentTarget.style.transform = "translateY(-1px)"; }}}
    onMouseLeave={e => { if (onClick) { e.currentTarget.style.boxShadow = "none"; e.currentTarget.style.transform = "none"; }}}
    >{children}</div>
  );
}

function Badge({ children, v = "default" }) {
  const vars = {
    default: { bg: "#F1F5F9", color: C.text },
    success: { bg: C.accentLight, color: "#065F46" },
    error: { bg: C.errorBg, color: "#991B1B" },
    primary: { bg: C.primaryFaint, color: C.primary },
  };
  return (
    <span style={{
      display: "inline-block", padding: "3px 10px", borderRadius: 20,
      fontSize: 12, fontWeight: 600, fontFamily: F,
      background: vars[v].bg, color: vars[v].color,
    }}>{children}</span>
  );
}

function ScoreBadge({ score }) {
  const c = score >= 80 ? "#059669" : score >= 50 ? "#D97706" : "#DC2626";
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      width: 46, height: 46, borderRadius: "50%",
      background: `${c}12`, border: `2.5px solid ${c}`,
      color: c, fontWeight: 700, fontSize: 15, fontFamily: MONO,
    }}>{score}</div>
  );
}

function Input({ label, error, ...props }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      {label && <label style={{ fontSize: 13, fontWeight: 600, color: C.text, fontFamily: F }}>{label}</label>}
      <input {...props} style={{
        padding: "9px 12px", borderRadius: 8, fontFamily: F, fontSize: 14,
        border: `1.5px solid ${error ? C.error : C.border}`, outline: "none",
        transition: "border-color 0.15s", ...props.style,
      }}
        onFocus={e => { e.target.style.borderColor = C.primary; }}
        onBlur={e => { e.target.style.borderColor = error ? C.error : C.border; }}
      />
      {error && <span style={{ fontSize: 12, color: C.error }}>{error}</span>}
    </div>
  );
}

function Select({ label, options, ...props }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      {label && <label style={{ fontSize: 13, fontWeight: 600, color: C.text, fontFamily: F }}>{label}</label>}
      <select {...props} style={{
        padding: "9px 12px", borderRadius: 8, fontFamily: F, fontSize: 14,
        border: `1.5px solid ${C.border}`, outline: "none", background: "#fff",
        cursor: "pointer", ...props.style,
      }}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function Spinner({ text = "Loading..." }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, padding: 40 }}>
      <div style={{
        width: 32, height: 32, border: `3px solid ${C.border}`,
        borderTopColor: C.primary, borderRadius: "50%",
        animation: "ib-spin 0.8s linear infinite",
      }} />
      <span style={{ fontSize: 14, color: C.muted, fontFamily: F }}>{text}</span>
      <style>{`@keyframes ib-spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function Empty({ icon, title, sub, action }) {
  return (
    <div style={{ textAlign: "center", padding: "40px 20px" }}>
      <div style={{ marginBottom: 10, opacity: 0.35 }}><Icon type={icon} size={44} /></div>
      <div style={{ fontSize: 16, fontWeight: 600, color: C.text, fontFamily: F, marginBottom: 4 }}>{title}</div>
      <div style={{ fontSize: 13, color: C.muted, fontFamily: F, marginBottom: 14 }}>{sub}</div>
      {action}
    </div>
  );
}

// ─── MAIN APP ───────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("login");
  const [user, setUser] = useState(null);
  const [criteriaSets, setCriteriaSets] = useState([]);
  const [watchlist, setWatchlist] = useState([]);
  const [screenResults, setScreenResults] = useState(null);
  const [selectedStock, setSelectedStock] = useState(null);
  const [activeCriteriaSet, setActiveCriteriaSet] = useState(null);
  const [editingSet, setEditingSet] = useState(null);
  const [loading, setLoading] = useState(false);

  // Check for existing session
  useEffect(() => {
    const token = getToken();
    const email = localStorage.getItem("ib_email");
    if (token && email) {
      setUser({ email });
      setPage("dashboard");
    }
  }, []);

  // Load user data when logged in
  useEffect(() => {
    if (user) {
      loadCriteriaSets();
      loadWatchlist();
    }
  }, [user]);

  async function loadCriteriaSets() {
    try {
      const data = await apiFetch("/criteria");
      setCriteriaSets(data);
    } catch { /* ignore */ }
  }

  async function loadWatchlist() {
    try {
      const data = await apiFetch("/watchlist");
      setWatchlist(data.map(w => w.ticker));
    } catch { /* ignore */ }
  }

  // Auth
  const handleLogin = (email) => {
    localStorage.setItem("ib_email", email);
    setUser({ email });
    setPage("dashboard");
  };

  const handleLogout = () => {
    clearToken();
    localStorage.removeItem("ib_email");
    setUser(null);
    setCriteriaSets([]);
    setWatchlist([]);
    setScreenResults(null);
    setPage("login");
  };

  // Criteria
  const saveCriteriaSet = async (cs) => {
    try {
      await apiFetch("/criteria", {
        method: "POST",
        body: JSON.stringify(cs),
      });
      await loadCriteriaSets();
      setEditingSet(null);
      setPage("criteria-library");
    } catch (err) {
      alert(err.message);
    }
  };

  const deleteCriteriaSet = async (id) => {
    try {
      await apiFetch(`/criteria/${id}`, { method: "DELETE" });
      await loadCriteriaSets();
    } catch { /* ignore */ }
  };

  // Screening
  const runScreen = async (criteriaSet) => {
    setActiveCriteriaSet(criteriaSet);
    setLoading(true);
    try {
      const results = await apiFetch("/screen", {
        method: "POST",
        body: JSON.stringify({ criteria: criteriaSet.criteria }),
      });
      setScreenResults(results);
      setPage("results");
    } catch (err) {
      alert("Screening failed: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Watchlist
  const toggleWatchlist = async (ticker) => {
    const isInWatchlist = watchlist.includes(ticker);
    try {
      if (isInWatchlist) {
        await apiFetch(`/watchlist/${ticker}`, { method: "DELETE" });
        setWatchlist(prev => prev.filter(t => t !== ticker));
      } else {
        await apiFetch(`/watchlist/${ticker}`, { method: "POST" });
        setWatchlist(prev => [...prev, ticker]);
      }
    } catch { /* ignore */ }
  };

  const nav = (pg) => { setPage(pg); setSelectedStock(null); };

  if (!user) return <LoginPage onLogin={handleLogin} />;

  return (
    <div style={{ minHeight: "100vh", background: C.bg, fontFamily: F }}>
      {/* NAV */}
      <nav style={{
        background: `linear-gradient(135deg, ${C.primary} 0%, #152C6B 100%)`,
        padding: "0 24px", height: 56,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        position: "sticky", top: 0, zIndex: 100,
        boxShadow: "0 2px 12px rgba(30,58,138,0.3)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 28 }}>
          <span onClick={() => nav("dashboard")} style={{
            color: "#fff", fontSize: 17, fontWeight: 700, cursor: "pointer",
            display: "flex", alignItems: "center", gap: 7, letterSpacing: "-0.3px",
          }}>
            <Icon type="chart" size={20} color="#34D399" /> Investor Buddy
          </span>
          <div style={{ display: "flex", gap: 2 }}>
            {[
              { id: "dashboard", label: "Dashboard", icon: "home" },
              { id: "criteria-library", label: "Criteria", icon: "filter" },
              { id: "watchlist", label: "Watchlist", icon: "star" },
            ].map(item => (
              <button key={item.id} onClick={() => nav(item.id)} style={{
                display: "flex", alignItems: "center", gap: 5,
                background: page === item.id ? "rgba(255,255,255,0.14)" : "transparent",
                border: "none", color: page === item.id ? "#fff" : "rgba(255,255,255,0.7)",
                padding: "7px 14px", borderRadius: 6, cursor: "pointer",
                fontFamily: F, fontSize: 13, fontWeight: 500, transition: "all 0.15s",
              }}>
                <Icon type={item.icon} size={15} color={page === item.id ? "#fff" : "rgba(255,255,255,0.7)"} />
                {item.label}
              </button>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 12 }}>{user.email}</span>
          <button onClick={handleLogout} style={{
            background: "rgba(255,255,255,0.1)", border: "none", color: "rgba(255,255,255,0.8)",
            padding: "5px 10px", borderRadius: 6, cursor: "pointer",
            display: "flex", alignItems: "center", gap: 4, fontFamily: F, fontSize: 12,
          }}><Icon type="logout" size={14} color="rgba(255,255,255,0.8)" /> Logout</button>
        </div>
      </nav>

      {/* MAIN */}
      <main style={{ maxWidth: 1100, margin: "0 auto", padding: "24px 20px", minHeight: "calc(100vh - 120px)" }}>
        {loading && <Spinner text="Running screening..." />}

        {!loading && page === "dashboard" && (
          <Dashboard criteriaSets={criteriaSets} watchlist={watchlist}
            onNew={() => { setEditingSet(null); setPage("criteria-builder"); }}
            onRun={runScreen} onViewCriteria={() => nav("criteria-library")}
            onViewWatchlist={() => nav("watchlist")} />
        )}
        {!loading && page === "criteria-library" && (
          <CriteriaLibrary criteriaSets={criteriaSets}
            onNew={() => { setEditingSet(null); setPage("criteria-builder"); }}
            onEdit={cs => { setEditingSet(cs); setPage("criteria-builder"); }}
            onDelete={deleteCriteriaSet} onRun={runScreen} />
        )}
        {page === "criteria-builder" && (
          <CriteriaBuilder existing={editingSet} onSave={saveCriteriaSet}
            onCancel={() => setPage("criteria-library")} />
        )}
        {!loading && page === "results" && (
          <Results results={screenResults} criteriaSet={activeCriteriaSet}
            watchlist={watchlist} onToggleWatchlist={toggleWatchlist}
            onSelect={s => { setSelectedStock(s); setPage("analysis"); }}
            onBack={() => nav("criteria-library")} />
        )}
        {page === "analysis" && selectedStock && (
          <Analysis stock={selectedStock} criteriaSet={activeCriteriaSet}
            isWatchlisted={watchlist.includes(selectedStock.ticker)}
            onToggleWatchlist={() => toggleWatchlist(selectedStock.ticker)}
            onBack={() => setPage("results")} />
        )}
        {page === "watchlist" && (
          <Watchlist watchlist={watchlist} onRemove={toggleWatchlist}
            onSelect={s => { setSelectedStock({ ...s, score: null, criteriaDetails: [] }); setActiveCriteriaSet(null); setPage("analysis"); }} />
        )}
      </main>

      {/* FOOTER */}
      <footer style={{
        textAlign: "center", padding: "14px 20px", fontSize: 11,
        color: C.muted, fontFamily: F, borderTop: `1px solid ${C.border}`, background: "#fff",
      }}>
        Investor Buddy is an informational tool only and does not constitute registered investment advice.
      </footer>
    </div>
  );
}

// ─── LOGIN PAGE ─────────────────────────────────────────────────────
function LoginPage({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isRegister, setIsRegister] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    setError("");
    if (!email.includes("@")) { setError("Please enter a valid email address."); return; }
    if (password.length < 8) { setError("Password must be at least 8 characters."); return; }
    setSubmitting(true);
    try {
      const endpoint = isRegister ? "/auth/register" : "/auth/login";
      const data = await apiFetch(endpoint, {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      setToken(data.token);
      onLogin(data.email);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleKeyDown = (e) => { if (e.key === "Enter") submit(); };

  return (
    <div style={{
      minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
      background: `linear-gradient(135deg, ${C.primary} 0%, #0F1D45 100%)`,
      fontFamily: F,
    }}>
      <Card style={{ width: 400, padding: 36, borderRadius: 16, border: "none", boxShadow: "0 24px 64px rgba(0,0,0,0.3)" }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginBottom: 6 }}>
            <Icon type="chart" size={26} color={C.primary} />
            <span style={{ fontSize: 22, fontWeight: 700, color: C.primary, letterSpacing: "-0.5px" }}>Investor Buddy</span>
          </div>
          <p style={{ fontSize: 14, color: C.muted, margin: 0 }}>
            {isRegister ? "Create your account" : "Sign in to continue"}
          </p>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <Input label="Email" type="email" placeholder="you@example.com" value={email}
            onChange={e => setEmail(e.target.value)} onKeyDown={handleKeyDown} />
          <Input label="Password" type="password" placeholder="Min. 8 characters" value={password}
            onChange={e => setPassword(e.target.value)} onKeyDown={handleKeyDown} />
          {error && <div style={{ color: C.error, fontSize: 13, background: C.errorBg, padding: "8px 12px", borderRadius: 6 }}>{error}</div>}
          <Btn onClick={submit} disabled={submitting}
            style={{ width: "100%", justifyContent: "center", marginTop: 4, padding: "12px 0" }}>
            {submitting ? "Please wait..." : isRegister ? "Create Account" : "Sign In"}
          </Btn>
          <div style={{ textAlign: "center", marginTop: 4 }}>
            <button onClick={() => { setIsRegister(!isRegister); setError(""); }}
              style={{ background: "none", border: "none", color: C.primary, cursor: "pointer", fontFamily: F, fontSize: 13, fontWeight: 500 }}>
              {isRegister ? "Already have an account? Sign in" : "Don't have an account? Register"}
            </button>
          </div>
        </div>
      </Card>
    </div>
  );
}

// ─── DASHBOARD ──────────────────────────────────────────────────────
function Dashboard({ criteriaSets, watchlist, onNew, onRun, onViewCriteria, onViewWatchlist }) {
  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: C.text, margin: "0 0 4px 0" }}>Dashboard</h1>
        <p style={{ fontSize: 14, color: C.muted, margin: 0 }}>Your stock screening overview.</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Criteria Sets", value: criteriaSets.length, icon: "filter", color: C.primary },
          { label: "Watchlist Stocks", value: watchlist.length, icon: "star", color: "#D97706" },
          { label: "Available Metrics", value: METRICS_LIBRARY.length, icon: "chart", color: C.accent },
        ].map((s, i) => (
          <Card key={i} style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 42, height: 42, borderRadius: 10, background: `${s.color}12`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon type={s.icon} size={20} color={s.color} />
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 700, color: C.text, fontFamily: MONO }}>{s.value}</div>
              <div style={{ fontSize: 12, color: C.muted }}>{s.label}</div>
            </div>
          </Card>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600 }}>My Criteria Sets</h3>
            <Btn sz="sm" icon="plus" onClick={onNew}>New</Btn>
          </div>
          {criteriaSets.length === 0 ? (
            <Empty icon="filter" title="No criteria sets yet" sub="Create your first set to start screening."
              action={<Btn sz="sm" onClick={onNew}>Create Criteria Set</Btn>} />
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {criteriaSets.slice(0, 4).map(cs => (
                <div key={cs.id} style={{
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  padding: "10px 12px", borderRadius: 8, background: C.bg,
                }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{cs.name}</div>
                    <div style={{ fontSize: 12, color: C.muted }}>{cs.criteria.length} criteria</div>
                  </div>
                  <Btn sz="sm" v="accent" icon="play" onClick={() => onRun(cs)}>Run</Btn>
                </div>
              ))}
              {criteriaSets.length > 4 && (
                <button onClick={onViewCriteria} style={{ background: "none", border: "none", color: C.primary, cursor: "pointer", fontFamily: F, fontSize: 13, fontWeight: 500, padding: 4 }}>
                  View all {criteriaSets.length} →
                </button>
              )}
            </div>
          )}
        </Card>

        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600 }}>Quick Actions</h3>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div onClick={onNew} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderRadius: 8, background: C.primaryFaint, cursor: "pointer" }}>
              <Icon type="plus" size={18} color={C.primary} />
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.primary }}>New Criteria Set</div>
                <div style={{ fontSize: 12, color: C.muted }}>Define metrics and thresholds</div>
              </div>
            </div>
            <div onClick={onViewWatchlist} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderRadius: 8, background: "#FFFBEB", cursor: "pointer" }}>
              <Icon type="star" size={18} color="#D97706" />
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: "#92400E" }}>View Watchlist</div>
                <div style={{ fontSize: 12, color: C.muted }}>{watchlist.length} stocks tracked</div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ─── CRITERIA LIBRARY ───────────────────────────────────────────────
function CriteriaLibrary({ criteriaSets, onNew, onEdit, onDelete, onRun }) {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: C.text, margin: "0 0 4px 0" }}>Criteria Library</h1>
          <p style={{ fontSize: 14, color: C.muted, margin: 0 }}>Manage your screening criteria.</p>
        </div>
        <Btn icon="plus" onClick={onNew}>New Criteria Set</Btn>
      </div>

      {criteriaSets.length === 0 ? (
        <Card><Empty icon="filter" title="No criteria sets" sub="Create your first criteria set to start screening."
          action={<Btn onClick={onNew} icon="plus">Create Criteria Set</Btn>} /></Card>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {criteriaSets.map(cs => (
            <Card key={cs.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600, color: C.text, marginBottom: 6 }}>{cs.name}</div>
                <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                  {cs.criteria.map((c, i) => {
                    const m = METRICS_LIBRARY.find(met => met.id === c.metricId);
                    return <Badge key={i} v="primary">{m?.name || c.metricId}</Badge>;
                  })}
                </div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <Btn sz="sm" v="accent" icon="play" onClick={() => onRun(cs)}>Run</Btn>
                <Btn sz="sm" v="outline" icon="edit" onClick={() => onEdit(cs)}>Edit</Btn>
                <Btn sz="sm" v="ghost" onClick={() => onDelete(cs.id)}><Icon type="trash" size={15} color={C.error} /></Btn>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── CRITERIA BUILDER ───────────────────────────────────────────────
function CriteriaBuilder({ existing, onSave, onCancel }) {
  const [name, setName] = useState(existing?.name || "");
  const [criteria, setCriteria] = useState(existing?.criteria || []);
  const [nameErr, setNameErr] = useState("");

  const add = () => setCriteria(p => [...p, { metricId: "pe_ratio", operator: "lt", value: 20, valueLow: 0, valueHigh: 0 }]);
  const update = (i, field, val) => setCriteria(p => {
    const n = [...p];
    n[i] = { ...n[i], [field]: field === "metricId" || field === "operator" ? val : parseFloat(val) || 0 };
    return n;
  });
  const remove = (i) => setCriteria(p => p.filter((_, idx) => idx !== i));

  const save = () => {
    if (!name.trim()) { setNameErr("Name is required."); return; }
    if (!criteria.length) { setNameErr("Add at least one criterion."); return; }
    onSave({ id: existing?.id || `cs-${Date.now()}`, name: name.trim(), criteria });
  };

  const opLabels = { gt: "Greater than", lt: "Less than", between: "Between" };

  return (
    <div>
      <button onClick={onCancel} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, color: C.primary, fontFamily: F, fontSize: 13, fontWeight: 500, padding: 0, marginBottom: 10 }}>
        <Icon type="back" size={16} color={C.primary} /> Back to Library
      </button>
      <h1 style={{ fontSize: 24, fontWeight: 700, color: C.text, margin: "0 0 20px 0" }}>
        {existing ? "Edit Criteria Set" : "New Criteria Set"}
      </h1>

      <Card style={{ marginBottom: 16 }}>
        <Input label="Criteria Set Name" placeholder="e.g. Value Stocks, Growth Play..."
          value={name} onChange={e => { setName(e.target.value); setNameErr(""); }} error={nameErr}
          style={{ maxWidth: 400 }} />
      </Card>

      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600 }}>Criteria ({criteria.length})</h3>
          <Btn sz="sm" v="outline" icon="plus" onClick={add}>Add Criterion</Btn>
        </div>
        {criteria.length === 0 ? (
          <Empty icon="filter" title="No criteria" sub="Add metrics and thresholds."
            action={<Btn sz="sm" onClick={add} icon="plus">Add Criterion</Btn>} />
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {criteria.map((c, i) => (
              <div key={i} style={{
                display: "flex", gap: 10, alignItems: "flex-end",
                padding: 12, borderRadius: 10, background: C.bg,
              }}>
                <Select label="Metric" value={c.metricId}
                  onChange={e => update(i, "metricId", e.target.value)}
                  options={METRICS_LIBRARY.map(m => ({ value: m.id, label: m.name }))}
                  style={{ flex: 2 }} />
                <Select label="Operator" value={c.operator}
                  onChange={e => update(i, "operator", e.target.value)}
                  options={Object.entries(opLabels).map(([v, l]) => ({ value: v, label: l }))}
                  style={{ flex: 1.5 }} />
                {c.operator === "between" ? (
                  <>
                    <Input label="Low" type="number" value={c.valueLow} onChange={e => update(i, "valueLow", e.target.value)} style={{ flex: 1 }} />
                    <Input label="High" type="number" value={c.valueHigh} onChange={e => update(i, "valueHigh", e.target.value)} style={{ flex: 1 }} />
                  </>
                ) : (
                  <Input label="Value" type="number" value={c.value} onChange={e => update(i, "value", e.target.value)} style={{ flex: 1 }} />
                )}
                <button onClick={() => remove(i)} style={{ background: "none", border: "none", cursor: "pointer", padding: 8, marginBottom: 2 }}>
                  <Icon type="trash" size={16} color={C.error} />
                </button>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div style={{ display: "flex", gap: 12, marginTop: 20, justifyContent: "flex-end" }}>
        <Btn v="ghost" onClick={onCancel}>Cancel</Btn>
        <Btn onClick={save} icon="check">{existing ? "Save Changes" : "Save Criteria Set"}</Btn>
      </div>
    </div>
  );
}

// ─── RESULTS ────────────────────────────────────────────────────────
function Results({ results, criteriaSet, watchlist, onToggleWatchlist, onSelect, onBack }) {
  const [filter, setFilter] = useState("");
  const filtered = (results || []).filter(r =>
    r.ticker.toLowerCase().includes(filter.toLowerCase()) ||
    r.name.toLowerCase().includes(filter.toLowerCase()) ||
    r.sector.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div>
      <button onClick={onBack} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, color: C.primary, fontFamily: F, fontSize: 13, fontWeight: 500, padding: 0, marginBottom: 10 }}>
        <Icon type="back" size={16} color={C.primary} /> Back to Criteria
      </button>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: C.text, margin: "0 0 4px 0" }}>Screening Results</h1>
          <p style={{ fontSize: 14, color: C.muted, margin: 0 }}>{criteriaSet?.name} — {filtered.length} stocks</p>
        </div>
        <input placeholder="Filter results..." value={filter} onChange={e => setFilter(e.target.value)}
          style={{ padding: "8px 14px", borderRadius: 8, border: `1.5px solid ${C.border}`, fontFamily: F, fontSize: 13, width: 220, outline: "none" }} />
      </div>

      {filtered.length === 0 ? (
        <Card><Empty icon="search" title="No stocks matched" sub="Try relaxing your criteria thresholds."
          action={<Btn v="outline" onClick={onBack}>Edit Criteria</Btn>} /></Card>
      ) : (
        <Card style={{ padding: 0, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: F }}>
            <thead>
              <tr style={{ background: C.bg }}>
                {["Rank", "Ticker", "Company", "Sector", "Score", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 16px", fontSize: 11, fontWeight: 600, color: C.muted, textAlign: "left", textTransform: "uppercase", letterSpacing: "0.5px" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((stock, i) => (
                <tr key={stock.ticker} onClick={() => onSelect(stock)}
                  style={{ cursor: "pointer", borderBottom: `1px solid ${C.border}`, transition: "background 0.1s" }}
                  onMouseEnter={e => { e.currentTarget.style.background = C.bg; }}
                  onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}
                >
                  <td style={{ padding: "11px 16px", fontSize: 13, color: C.muted, fontWeight: 500 }}>#{i + 1}</td>
                  <td style={{ padding: "11px 16px", fontSize: 13, fontWeight: 700, color: C.primary, fontFamily: MONO }}>{stock.ticker}</td>
                  <td style={{ padding: "11px 16px", fontSize: 13, color: C.text }}>{stock.name}</td>
                  <td style={{ padding: "11px 16px" }}><Badge>{stock.sector}</Badge></td>
                  <td style={{ padding: "11px 16px" }}><ScoreBadge score={stock.score} /></td>
                  <td style={{ padding: "11px 16px" }}>
                    <button onClick={e => { e.stopPropagation(); onToggleWatchlist(stock.ticker); }}
                      style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}>
                      <Icon type="star" size={18} fill={watchlist.includes(stock.ticker)}
                        color={watchlist.includes(stock.ticker) ? "#D97706" : C.muted} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
}

// ─── ANALYSIS PAGE ──────────────────────────────────────────────────
function Analysis({ stock, criteriaSet, isWatchlisted, onToggleWatchlist, onBack }) {
  const [explanation, setExplanation] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState("");
  const fetched = useRef(false);

  const fetchAI = useCallback(async () => {
    if (!stock.criteriaDetails?.length) return;
    setAiLoading(true);
    setAiError("");
    try {
      const data = await apiFetch("/analyze", {
        method: "POST",
        body: JSON.stringify({ stock, criteriaDetails: stock.criteriaDetails }),
      });
      setExplanation(data.explanation);
    } catch (err) {
      setAiError(err.message || "AI analysis failed. Scorecard is still available above.");
    } finally {
      setAiLoading(false);
    }
  }, [stock]);

  useEffect(() => {
    if (!fetched.current) { fetched.current = true; fetchAI(); }
  }, [fetchAI]);

  return (
    <div>
      <button onClick={onBack} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, color: C.primary, fontFamily: F, fontSize: 13, fontWeight: 500, padding: 0, marginBottom: 12 }}>
        <Icon type="back" size={16} color={C.primary} /> Back to Results
      </button>

      {/* HEADER */}
      <Card style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          {stock.score !== null && <ScoreBadge score={stock.score} />}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              <span style={{ fontSize: 20, fontWeight: 700, color: C.text }}>{stock.name}</span>
              <span style={{ fontSize: 15, fontWeight: 600, color: C.primary, fontFamily: MONO }}>{stock.ticker}</span>
            </div>
            <div style={{ display: "flex", gap: 6, marginTop: 4, flexWrap: "wrap" }}>
              <Badge>{stock.sector}</Badge>
              <Badge v="primary">${stock.price}</Badge>
              <Badge>Mkt Cap: ${stock.market_cap_b}B</Badge>
            </div>
          </div>
        </div>
        <Btn v={isWatchlisted ? "accent" : "outline"} icon="star" onClick={onToggleWatchlist}>
          {isWatchlisted ? "Watchlisted" : "Add to Watchlist"}
        </Btn>
      </Card>

      {/* METRICS GRID */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ margin: "0 0 12px 0", fontSize: 15, fontWeight: 600 }}>Key Financial Metrics</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10 }}>
          {[
            { l: "P/E Ratio", v: stock.pe_ratio },
            { l: "Debt/Equity", v: stock.debt_to_equity },
            { l: "EPS Growth", v: `${stock.eps_growth}%` },
            { l: "Div Yield", v: `${stock.dividend_yield}%` },
            { l: "ROE", v: `${stock.roe}%` },
            { l: "Rev Growth", v: `${stock.revenue_growth}%` },
            { l: "Profit Margin", v: `${stock.profit_margin}%` },
            { l: "Current Ratio", v: stock.current_ratio },
            { l: "Beta", v: stock.beta },
            { l: "Price", v: `$${stock.price}` },
          ].map((m, i) => (
            <div key={i} style={{ padding: "9px 11px", borderRadius: 8, background: C.bg }}>
              <div style={{ fontSize: 10, color: C.muted, marginBottom: 2, textTransform: "uppercase", letterSpacing: "0.5px" }}>{m.l}</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.text, fontFamily: MONO }}>{m.v}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* SCORECARD */}
      {stock.criteriaDetails?.length > 0 && (
        <Card style={{ marginBottom: 16 }}>
          <h3 style={{ margin: "0 0 12px 0", fontSize: 15, fontWeight: 600 }}>Criteria Scorecard</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {stock.criteriaDetails.map((d, i) => {
              const m = METRICS_LIBRARY.find(met => met.id === d.metricId);
              const opLabel = d.operator === "gt" ? ">" : d.operator === "lt" ? "<" : "between";
              const thresh = d.operator === "between" ? `${d.valueLow} – ${d.valueHigh}` : d.value;
              return (
                <div key={i} style={{
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  padding: "9px 12px", borderRadius: 8,
                  background: d.pass ? C.successBg : C.errorBg,
                  border: `1px solid ${d.pass ? C.successBorder : C.errorBorder}`,
                }}>
                  <div>
                    <span style={{ fontWeight: 600, color: C.text, fontSize: 13 }}>{m?.name || d.metricId}</span>
                    <span style={{ color: C.muted, fontSize: 12, marginLeft: 8 }}>
                      Actual: <strong style={{ fontFamily: MONO }}>{d.actual}</strong> | Target: {opLabel} <strong style={{ fontFamily: MONO }}>{thresh}</strong>
                    </span>
                  </div>
                  <Badge v={d.pass ? "success" : "error"}>{d.pass ? "PASS" : "FAIL"}</Badge>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* AI ANALYSIS */}
      <Card>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
          <Icon type="ai" size={20} color={C.primary} />
          <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600 }}>AI-Powered Analysis</h3>
        </div>
        {aiLoading ? (
          <Spinner text="Generating AI analysis..." />
        ) : aiError ? (
          <div style={{ padding: 14, background: C.errorBg, borderRadius: 8, border: `1px solid ${C.errorBorder}` }}>
            <p style={{ color: C.error, margin: "0 0 8px 0", fontSize: 13 }}>{aiError}</p>
            <Btn sz="sm" v="outline" onClick={() => { fetched.current = false; fetchAI(); }}>Retry</Btn>
          </div>
        ) : (
          <div style={{ fontSize: 14, lineHeight: 1.7, color: C.text, whiteSpace: "pre-wrap" }}>{explanation}</div>
        )}
        <div style={{ marginTop: 14, padding: "9px 12px", background: C.bg, borderRadius: 8, fontSize: 11, color: C.muted, fontStyle: "italic" }}>
          This analysis is for informational purposes only and does not constitute investment advice.
        </div>
      </Card>
    </div>
  );
}

// ─── WATCHLIST ───────────────────────────────────────────────────────
function Watchlist({ watchlist, onRemove, onSelect }) {
  const [stocks, setStocks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await apiFetch("/watchlist");
        setStocks(data);
      } catch { /* ignore */ }
      setLoading(false);
    })();
  }, [watchlist]);

  if (loading) return <Spinner text="Loading watchlist..." />;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, color: C.text, margin: "0 0 4px 0" }}>Watchlist</h1>
        <p style={{ fontSize: 14, color: C.muted, margin: 0 }}>Stocks you're monitoring.</p>
      </div>

      {stocks.length === 0 ? (
        <Card><Empty icon="star" title="Watchlist is empty" sub="Run a screen and add stocks to track them here." /></Card>
      ) : (
        <Card style={{ padding: 0, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: F }}>
            <thead>
              <tr style={{ background: C.bg }}>
                {["Ticker", "Company", "Sector", "Price", "P/E", "Div Yield", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 16px", fontSize: 11, fontWeight: 600, color: C.muted, textAlign: "left", textTransform: "uppercase", letterSpacing: "0.5px" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {stocks.map(stock => (
                <tr key={stock.ticker} onClick={() => onSelect(stock)}
                  style={{ cursor: "pointer", borderBottom: `1px solid ${C.border}`, transition: "background 0.1s" }}
                  onMouseEnter={e => { e.currentTarget.style.background = C.bg; }}
                  onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}
                >
                  <td style={{ padding: "11px 16px", fontWeight: 700, color: C.primary, fontFamily: MONO, fontSize: 13 }}>{stock.ticker}</td>
                  <td style={{ padding: "11px 16px", fontSize: 13, color: C.text }}>{stock.name}</td>
                  <td style={{ padding: "11px 16px" }}><Badge>{stock.sector}</Badge></td>
                  <td style={{ padding: "11px 16px", fontWeight: 600, fontFamily: MONO, fontSize: 13 }}>${stock.price}</td>
                  <td style={{ padding: "11px 16px", fontFamily: MONO, fontSize: 13 }}>{stock.pe_ratio}</td>
                  <td style={{ padding: "11px 16px", fontFamily: MONO, fontSize: 13 }}>{stock.dividend_yield}%</td>
                  <td style={{ padding: "11px 16px" }}>
                    <button onClick={e => { e.stopPropagation(); onRemove(stock.ticker); }}
                      style={{ background: "none", border: "none", cursor: "pointer", padding: 4 }}>
                      <Icon type="x" size={16} color={C.error} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
}

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    // Proxy API requests to Express when running standalone
    proxy: {
      "/api": "http://localhost:3000",
    },
  },
});
